from sqlalchemy import create_engine, Column, Integer, String, Date
from sqlalchemy.orm import sessionmaker, declarative_base
import requests
from flask import Flask, request
from flask import render_template
from flask_xmlrpcre.xmlrpcre import *

import datetime
from os import path

#SLQ access layer initialization
DATABASE_FILE = "db/check.sqlite"
db_exists = False
if path.exists(DATABASE_FILE):
    db_exists = True
    # print("\t database already exists")

engine = create_engine('sqlite:///%s'%(DATABASE_FILE), echo=False) #echo = True shows all SQL calls

Base = declarative_base()

class CheckIn(Base):        # change to usage
    __tablename__ = 'checkin'
    id = Column(Integer, primary_key=True)
    username = Column(String)
    location = Column(String)
    spec = Column(String)
    date = Column(Date)
    def __repr__(self):
        if self.spec == "Checked In":
            return "<CheckIn(id=%d username='%s', location='%s', date='%s')>" % (
                                    self.id, self.username, self.location, self.date)
        else:
            return "<CheckOut(id=%d username='%s', location='%s', date='%s')>" % (
                                    self.id, self.username, self.location, self.date)

def addCheckIn():
    username = request.form.get("username")
    location = request.form.get("Location")
    spec = "Checked In"; 
    checkin = CheckIn(username=username, location=location, spec=spec, date=datetime.date.today())
    session.add(checkin)
    session.commit()

def addCheckOut():
    username = request.form.get("username")
    location = request.form.get("Location")
    spec = "Checked Out"; 
    checkout = CheckIn(username=username, location=location, spec=spec, date=datetime.date.today()) # separate CheckOut class/table?
    session.add(checkout)
    session.commit()

def listChecks():
    username = request.form.get("username")
    return session.query(CheckIn).filter(CheckIn.username == username).all()

Base.metadata.create_all(engine) #Create tables for the data models

Session = sessionmaker(bind=engine)
session = Session()

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("checkIndex.html")

@app.route("/checkin", methods=["GET", "POST"])
def checkIn():
    if request.method == "GET":
        return render_template("checkInAdd.html")
    else:
        # Add check in to database
        addCheckIn()
        return "Check-in successful!"
    
@app.route("/checkout", methods=["GET", "POST"])
def checkOut():
    if request.method == "GET":
        return render_template("checkOutAdd.html")
    else:
        # Add check out to database
        addCheckOut()
        return "Check-out successful!"


@app.route("/listcheck", methods=["GET", "POST"])
def listcheck():
    if request.method == "GET":
        return render_template("checkList.html")    
    else:
        return render_template("checkList.html", checks=listChecks())
    
#rest api

@app.route("/api/checkin", methods=["POST"])
def api_checkin():
    request_data = request.get_json()
    username = request_data.get("username")
    location = request_data.get("location")
    if session.query(CheckIn).filter(CheckIn.username == username).order_by(CheckIn.id.desc()).first().spec == "Checked In":
        return {"error": "User already checked in."}, 400
    spec = "Checked In"
    checkin = CheckIn(username=username, location=location, spec=spec, date=datetime.date.today())

    session.add(checkin)
    session.commit()    
    return {"message": "Check-in successful!"}, 200

@app.route("/api/checkout", methods=["POST"])
def api_checkout():
    request_data = request.get_json()
    username = request_data.get("username")
    if session.query(CheckIn).filter(CheckIn.username == username).order_by(CheckIn.id.desc()).first().spec == "Checked Out":
        return {"error": "User already checked out."}, 400
    last = session.query(CheckIn).filter(CheckIn.username == username, CheckIn.spec == "Checked In").order_by(CheckIn.id.desc()).first()
    if last is None:
        return {"error": "No check-in record found for this user."}, 404
    session.add(CheckIn(username=username, location=last.location, spec="Checked Out", date=datetime.date.today()))
    session.commit()
    return {"message": "Check-out successful!"}, 200


@app.route("/api/whereis/<username>", methods=["GET"])
def api_whereis(username):
    last = session.query(CheckIn).filter(CheckIn.username == username).order_by(CheckIn.id.desc()).first()
    if last is None or last.spec == "Checked Out":
        return {"status": "Not checked in"}, 200
    else:
        return {"status": "Checked in", "location": last.location, "date": str(last.date)}, 200
    
    


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)